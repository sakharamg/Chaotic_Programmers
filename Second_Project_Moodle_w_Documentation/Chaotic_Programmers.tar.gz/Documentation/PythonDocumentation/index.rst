.. A documentation master file, created by
   sphinx-quickstart on Tue Oct 26 22:37:39 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Student Companion's documentation!
=============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   modules/all-about-me.rst
   
   modules/all-about-project.rst
   
   modules/views.rst
   
   modules/models.rst
   
   modules/serializers.rst
   
   modules/apps.rst
   
   modules/lib.rst
   
   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
