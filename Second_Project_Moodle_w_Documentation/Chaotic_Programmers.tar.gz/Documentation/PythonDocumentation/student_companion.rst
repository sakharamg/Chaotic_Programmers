student\_companion package
==========================

Submodules
----------

student\_companion.asgi module
------------------------------

.. automodule:: student_companion.asgi
   :members:
   :undoc-members:
   :show-inheritance:

student\_companion.settings module
----------------------------------

.. automodule:: student_companion.settings
   :members:
   :undoc-members:
   :show-inheritance:

student\_companion.urls module
------------------------------

.. automodule:: student_companion.urls
   :members:
   :undoc-members:
   :show-inheritance:

student\_companion.wsgi module
------------------------------

.. automodule:: student_companion.wsgi
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: student_companion
   :members:
   :undoc-members:
   :show-inheritance:
