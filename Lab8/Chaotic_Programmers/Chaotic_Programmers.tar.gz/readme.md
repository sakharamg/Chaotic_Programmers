**Team Name:** Chaotic_Programmers  
**Roll No:**  
213050082  
21q050004  
213050027  

**Contribution:**  
213050082: complete implementation of q1 and q3.  
21q050004: complete implementation of q2 and q4.  
213050027: complete implementation of q5(Matrix) ,q6 and q7.  

**References:**    

**q1:**  
  
1. *Java filesystem:* https://www.javatpoint.com/java-file-class  
2. *Delete content in file:* https://www.geeksforgeeks.org/java-program-delete-certain-text-file/  
3. *Copying contenst from one file to another:* https://www.geeksforgeeks.org/different-ways-to-copy-content-from-one-file-to-another-file-in-java/  

**q2:**  

1. *Collections sort:* https://www.geeksforgeeks.org/collections-sort-java-examples/  
2. *ArrayList:* https://www.geeksforgeeks.org/arraylist-in-java/  

**q3:**  

1. *Pattern matching:* https://www.w3schools.com/java/java_regex.asp  
2. *Regular Expressions in Java:* https://beginnersbook.com/2014/08/java-regex-tutorial/  
https://www.geeksforgeeks.org/regular-expressions-in-java/  
https://www.javatpoint.com/java-regex  


**q4:**   

1. *Threads in Java:* https://www.geeksforgeeks.org/java-program-to-create-a-thread/  
2. *Runnable interface in java:* https://www.geeksforgeeks.org/runnable-interface-in-java/  
3. *Exception handling Threads:* https://stackoverflow.com/questions/18025337/fixing-error-unreported-exception-interruptedexception/18025466  

**q5:**   

1. *Multi-dimensional array:* https://www.geeksforgeeks.org/multidimensional-arrays-in-java/  
2. *Constructor in Java:* https://www.javatpoint.com/java-constructor#conspara  
3. *Getting Dimension in Java:* https://www.codegrepper.com/code-examples/java/how+to+get+the+dimensions+of+a+2d+array+in+java  
4. *Get Data in Java:* https://www.javatpoint.com/java-get-current-date  


**q6 and q7:**   

1. *Makefile tutorial:* https://www.cs.colby.edu/maxwell/courses/tutorials/maketutor/  
https://makefiletutorial.com/  
2. *Using gcc in Make:* https://web.eecs.umich.edu/~sugih/pointers/make.html  
3. *Hiding entry and exit directory messages:* https://stackoverflow.com/questions/9967392/make1-entering-directory-error-message  
4. *Top Make file tutorial:* https://www.linuxquestions.org/questions/mandriva-30/how-to-create-a-top-level-makefile-604860/  
5. *Compiling multiple C files:* https://stackoverflow.com/questions/1305665/how-to-compile-different-c-files-with-different-cflags-using-makefile  
6. *Calling Makefile from top make file:* https://stackoverflow.com/questions/2206128/how-to-call-makefile-from-another-makefile  
7. *Functions in makefile:* https://www.gnu.org/software/make/manual/html_node/File-Name-Functions.html#File-Name-Functions  
8. *Automatic Variables in Make file:* https://www.gnu.org/software/make/manual/html_node/Automatic-Variables.html  
9. *Macros in Makefile: https://stackoverflow.com/questions/23843106/how-to-set-child-process-environment-variable-in-makefile  
