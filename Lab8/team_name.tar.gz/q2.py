class TWODMAT:
    def nor_mat(arr):
        #arr- a matrix of a given dimension MxN
        
        
    def sum_fil(arr,k):
        #arr-array of shape (n) 
        #k-kernal size
        
        
    def top_pos(arr,k):
        #arr-a matrix of shape (m,n). 
        #k-top k values

if __name__ == '__main__':