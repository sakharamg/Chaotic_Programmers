import numpy as np
from matplotlib import pyplot as plt

# write your code here!
