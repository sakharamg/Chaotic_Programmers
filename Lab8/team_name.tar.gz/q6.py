import json


def processData( input_path, output_path ):
    '''  write your code here '''
    print(input_path)
    print(output_path)
    


if __name__ == "__main__":
    '''
        Remove this comment.
        This is just for you to run and check your code.

        To test your function we will import this file and call your function.
        Before running give appropriate file path for path_to_input_json below. 
    '''
    path_to_input_json = './testcases/q6/q6_input.json'
    path_to_output_json = './testcases/q6/q6_output.json'
    processData( path_to_input_json, path_to_output_json )
    
