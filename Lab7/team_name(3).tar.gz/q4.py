from stackapi import StackAPI
import pandas as pd
import sys

#inp is a list of tags(input)
def function_q4(inp):
    #Write your code here


if __name__=="__main__":
    n=len(sys.argv)  
    inp = []
    for i in range(1,n):
        inp.append(sys.argv[i])
    function_q4(inp)
