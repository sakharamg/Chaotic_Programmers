def find_prime(n,m):
    ''' find_prime(n,m) should return the
        the count of prime number between n and m
        (inclusive of n and m)

        return integer
    '''
    

