**Team Name:** Chaotic_Programmers  
**Roll No:**  
213050082  
21q050004  
213050027  

Overleaf link (viewable):https://www.overleaf.com/read/mpdkkmszxqzp  

**References:**  

1. *Adding bibliography in latex:* https://www.overleaf.com/learn/latex/Bibliography_management_with_bibtex  
2. *Latex Color themes:* https://deic-web.uab.cat/~iblanes/beamer_gallery/index.html 
3. *Adding and shrinking images in latex* : https://www.overleaf.com/learn/latex/Inserting_Images
